import uuid
import json

class Reading:

    def __init__(self):
        self.carnumber = int()
        self.carclass = str()
        self.reading = str()
